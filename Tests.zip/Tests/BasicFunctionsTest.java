
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.seleniumhq.jetty9.util.log.Log;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.assertEquals;

// TODO: Don't move the mouse when running test. It may conflict with some tests. As well as close any Spotify application if open.
// @pre: There is at least a dozen song in queue(estimate) to allow subsequent operations && start on Pause(or Play in HTML)
public class BasicFunctionsTest {
    WebDriver webDriver;
    WebDriverWait wait;
    String url;
    SpotifyMainPage m;
    @BeforeTest
    public void setup() throws NoSuchFieldException, IllegalAccessException {
        // TODO: local chrome driver
        System.setProperty("");
        webDriver = new ChromeDriver();
        wait = new WebDriverWait(webDriver, 5);
        url = "https://open.spotify.com/";
        webDriver.get(url);
        LogInTest();
        m = new SpotifyMainPage(webDriver);
        clearCookie();
    }

    public void LogInTest() throws NoSuchFieldException, IllegalAccessException {
        SpotifyStartPage s = new SpotifyStartPage(webDriver);
        s.goToSpotifyLoginPage();
        SpotifyLoginPage l = new SpotifyLoginPage(webDriver);

        // Access private element username
        Field privateLoginElement = SpotifyLoginPage.class.getDeclaredField("aUsername");
        privateLoginElement.setAccessible(true);
        By loginElement = (By) privateLoginElement.get(l);

        // Set up explicit wait
        // Wait for the loading of the MainPage
        wait.until(ExpectedConditions.visibilityOfElementLocated(loginElement));
        // TODO: Spotify credentials
        l.loginToSpotify();
    }

    public void clearCookie() throws IllegalAccessException, NoSuchFieldException {
        Field privateCookieButton = SpotifyMainPage.class.getDeclaredField("aCookieButton");
        privateCookieButton.setAccessible(true);
        By cookieButton = (By) privateCookieButton.get(m);
        wait.until(ExpectedConditions.visibilityOfElementLocated(cookieButton));
        m.clickCookieExitButton();
    }

    @Test
    /**
     * @pre PlayButton aria-label == Pause
     */
    public void PlayAndPauseTest() throws NoSuchFieldException, IllegalAccessException, InterruptedException {
        // Set up
        // Access private element aPlay
        Field privatePlayElement = SpotifyMainPage.class.getDeclaredField("aPlay");
        privatePlayElement.setAccessible(true);
        By playElement = (By) privatePlayElement.get(m);
        // Wait for the loading of the MainPage
        wait.until(ExpectedConditions.visibilityOfElementLocated(playElement));
        m.togglePlayButton();
        // Explicit wait for the attribute Pause, else throw ElementNotVisibleException
        WebElement curElement = webDriver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/footer/div[1]/div[2]/div/div[1]/button[3]"));
        wait.until(ExpectedConditions.attributeContains(curElement,"aria-label", "Pause") );
        m.togglePlayButton();
        wait.until(ExpectedConditions.attributeContains(curElement,"aria-label", "Play") );
    }

    @Test
    /**
     * @pre PlayButton aria-label == Pause
     */
    public void nextButtonTest() throws NoSuchFieldException, IllegalAccessException, InterruptedException {
        // Set up
        // Access private element aNext
        Field privateNextElement = SpotifyMainPage.class.getDeclaredField("aNext");
        privateNextElement.setAccessible(true);
        By nextElement = (By) privateNextElement.get(m);

        // Explicit wait for page to load Next element
        wait.until(ExpectedConditions.visibilityOfElementLocated(nextElement));
        m.toggleNextButton();
        // Explicit wait for the attribute Pause, else throw ElementNotVisibleException
        WebElement curElement = webDriver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/footer/div[1]/div[2]/div/div[1]/button[3]"));
        wait.until(ExpectedConditions.attributeContains(curElement,"aria-label", "Pause") );
        m.togglePlayButton();
        wait.until(ExpectedConditions.attributeContains(curElement,"aria-label", "Play") );
    }

    @Test
    public void previousButtonTest() throws NoSuchFieldException, IllegalAccessException, InterruptedException {
        // Set up
        // Access private element aPrevious
        Field privatePreviousButton = SpotifyMainPage.class.getDeclaredField("aPrevious");
        privatePreviousButton.setAccessible(true);
        By previousElement = (By) privatePreviousButton.get(m);
        // Wait for the loading of the MainPage
        wait.until(ExpectedConditions.visibilityOfElementLocated(previousElement));

        WebElement w = webDriver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/footer/div[1]/div[2]/div/div[2]/div[1]"));
        // Two different states: from the start and else
        // Start
        if(w.getText().equals("0:00")){
            m.togglePreviousButton();
            // Explicit wait for the attribute Pause, else throw ElementNotVisibleException
            WebElement curElement = webDriver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/footer/div[1]/div[2]/div/div[1]/button[3]"));
            wait.until(ExpectedConditions.attributeContains(curElement,"aria-label", "Pause") );
        }
        else{
            WebElement curElement = webDriver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/footer/div[1]/div[2]/div/div[1]/button[3]"));
            if(curElement.getAttribute("aria-label").equals("Pause")) {
                m.togglePlayButton();
                wait.until(ExpectedConditions.attributeToBe(curElement,"aria-label","Play"));
                m.togglePreviousButton();
                //w = webDriver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/footer/div[1]/div[2]/div/div[2]/div[1]"));
                wait.until(ExpectedConditions.textToBePresentInElementValue(w, "0:00"));
            }
        }
    }

    @Test
    public void shuffleButtonTest() throws NoSuchFieldException, IllegalAccessException, InterruptedException {
        // Set up
        // Access private element aShuffle
        Field privateShuffleButton = SpotifyMainPage.class.getDeclaredField("aShuffle");
        privateShuffleButton.setAccessible(true);
        By shuffleElement = (By) privateShuffleButton.get(m);
        // Wait for the loading of the MainPage
        wait.until(ExpectedConditions.visibilityOfElementLocated(shuffleElement));

        WebElement w = webDriver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/footer/div[1]/div[2]/div/div[1]/button[1]"));
        // Shuffle has 2 states: Enable shuffle, disable shuffle
        // Enable shuffle
        if(w.getAttribute("title").equals("Enable shuffle")){
            m.toggleShuffleButton();
            wait.until(ExpectedConditions.attributeContains(w, "title", "Disable shuffle"));
        }
        else{
            m.toggleShuffleButton();
            wait.until(ExpectedConditions.attributeContains(w, "title", "Enable shuffle"));
        }
    }

    @Test
    public void repeatButtonTest() throws NoSuchFieldException, IllegalAccessException, InterruptedException {
        // Set up
        // Access private element aRepeat
        Field privateRepeatButton = SpotifyMainPage.class.getDeclaredField("aRepeat");
        privateRepeatButton.setAccessible(true);
        By repeatElement = (By) privateRepeatButton.get(m);
        // Wait for the loading of the MainPage
        wait.until(ExpectedConditions.visibilityOfElementLocated(repeatElement));

        WebElement w = webDriver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/footer/div[1]/div[2]/div/div[1]/button[5]"));
        // Repeat has 3 states: Enable repeat, Enable repeat one, Disable repeat
        if(w.getAttribute("title").equals("Enable repeat")){
            m.toggleRepeatButton();
            wait.until(ExpectedConditions.attributeContains(w,"title", "Enable repeat one"));
        }
        else if(w.getAttribute("title").equals("Enable repeat one")){
            m.toggleRepeatButton();
            wait.until(ExpectedConditions.attributeContains(w, "title", "Disable repeat"));
        }
        else{
            m.toggleRepeatButton();
            wait.until(ExpectedConditions.attributeContains(w,"title","Enable repeat"));
        }

    }

    @Test
    // TODO: IN PROGRESS
    // Testing progress bar to 0.00
    public void progressbarTest() throws NoSuchFieldException, IllegalAccessException, InterruptedException {
        // Access private element aProgressBar
        Field privateProgressBar = SpotifyMainPage.class.getDeclaredField("aProgressBar");
        privateProgressBar.setAccessible(true);
        By progressbarElement = (By) privateProgressBar.get(m);
        // Wait for the loading of the MainPage
        wait.until(ExpectedConditions.visibilityOfElementLocated(progressbarElement));
        m.setProgressBar(0);
        WebElement w = webDriver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/footer/div/div[2]/div/div[2]/div[1]"));
        assertEquals("0:00", w.getText());
    }

    @AfterTest
    public void closeBrowser(){
        webDriver.quit();
    }
}
