import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.lang.reflect.Field;

public class BonusTest {
    WebDriver webDriver;
    WebDriverWait wait;
    String url;
    SpotifyMainPage m;
    @BeforeTest
    public void setup() throws NoSuchFieldException, IllegalAccessException {
        // TODO: local chrome driver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\ToFoo\\Downloads\\chromedriver_win32\\chromedriver.exe");
        webDriver = new ChromeDriver();
        wait = new WebDriverWait(webDriver, 5);
        url = "https://open.spotify.com/";
        webDriver.get(url);
        LogInTest();
        m = new SpotifyMainPage(webDriver);
        clearCookie();
    }

    public void LogInTest() throws NoSuchFieldException, IllegalAccessException {
        SpotifyStartPage s = new SpotifyStartPage(webDriver);
        s.goToSpotifyLoginPage();
        SpotifyLoginPage l = new SpotifyLoginPage(webDriver);

        // Access private element username
        Field privateLoginElement = SpotifyLoginPage.class.getDeclaredField("aUsername");
        privateLoginElement.setAccessible(true);
        By loginElement = (By) privateLoginElement.get(l);

        // Set up explicit wait
        // Wait for the loading of the MainPage
        wait.until(ExpectedConditions.visibilityOfElementLocated(loginElement));
        // TODO: Spotify credentials
        l.loginToSpotify("tofoo_power@hotmail.com", "06##GXVzQt6X");
    }

    public void clearCookie() throws IllegalAccessException, NoSuchFieldException {
        Field privateCookieButton = SpotifyMainPage.class.getDeclaredField("aCookieButton");
        privateCookieButton.setAccessible(true);
        By cookieButton = (By) privateCookieButton.get(m);
        wait.until(ExpectedConditions.visibilityOfElementLocated(cookieButton));
        m.clickCookieExitButton();
    }
    @Test
    /**
     * Next -> Previous and verify the name of the song
     * Note : can fail if referenced element is not on the dom (StaleElementReferenceException)
     */
    public void BonusTest1() throws NoSuchFieldException, IllegalAccessException {
        // Set up
        // Access private element aNext
        Field privateNextElement = SpotifyMainPage.class.getDeclaredField("aNext");
        privateNextElement.setAccessible(true);
        By nextElement = (By) privateNextElement.get(m);

        // Explicit wait for page to load Next element
        wait.until(ExpectedConditions.visibilityOfElementLocated(nextElement));
        /*
        String s = webDriver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/footer/div[1]/div[2]/div/div[1]/button[3]")).getAttribute("aria-label");
        // @pre
        assert s.equals("Play");
        */
        try {
            WebElement w = webDriver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/footer/div[1]/div[1]/div/div[2]/div[1]/span/a"));
            //String songAlbum = w.getAttribute("href");
            String songName = w.getText();

            m.toggleNextButton();

            // Explicit wait for the attribute Pause, else throw ElementNotVisibleException
            WebElement curElement = webDriver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/footer/div[1]/div[2]/div/div[1]/button[3]"));
            wait.until(ExpectedConditions.not(ExpectedConditions.textToBePresentInElementValue(w, songName)));
            wait.until(ExpectedConditions.attributeContains(curElement, "aria-label", "Pause"));
            WebElement w_Next = webDriver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div[2]/footer/div[1]/div[1]/div/div[2]/div[1]/span/a"));
            //String songAlbumNext = w_Next.getAttribute("href");
            String songNameNext = w_Next.getText();
            //assertThat(songAlbum, is(not(songAlbumNext)));
            assertThat(songName, is(not(songNameNext)));
        }
        catch (StaleElementReferenceException e){
            System.out.println("The element is not attached to the page document.");
        }
    }
    @AfterTest
    public void closeBrowser(){
        webDriver.quit();
    }
}
