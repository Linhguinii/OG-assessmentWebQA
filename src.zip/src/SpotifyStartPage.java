import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SpotifyStartPage {
    private WebDriver aDriver;
    private By aLogin = By.xpath("//*[@id=\"main\"]/div/div[2]/div[1]/header/div[5]/button[2]");

    public SpotifyStartPage(WebDriver pDriver){
        aDriver = pDriver;
    }

    private void clickLogin(){
        aDriver.findElement(aLogin).click();
    }

    public void goToSpotifyLoginPage(){
        this.clickLogin();
    }

}
